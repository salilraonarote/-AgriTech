import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
dotenv.config();

const app=express();
app.use(cors());
app.use(express.json());

const User=mongoose.model('User',new mongoose.Schema({
 name:{type:String,required:true},email:{type:String,unique:true,required:true},
 password:{type:String,required:true},role:{type:String,enum:['farmer','admin'],default:'farmer'},
 language:{type:String,default:'en'},createdAt:{type:Date,default:Date.now}
}));
const Farm=mongoose.model('Farm',new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
 name:String,location:String,area:Number,soilType:String
},{timestamps:true}));
const Crop=mongoose.model('Crop',new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
 farm:{type:mongoose.Schema.Types.ObjectId,ref:'Farm'},name:String,variety:String,
 sowingDate:String,stage:String,health:String,notes:String
},{timestamps:true}));
const SoilReport=mongoose.model('SoilReport',new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},farm:String,ph:Number,nitrogen:Number,
 phosphorus:Number,potassium:Number,notes:String,createdAt:{type:Date,default:Date.now}
}));
const Alert=mongoose.model('Alert',new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},title:String,message:String,severity:String,
 createdAt:{type:Date,default:Date.now}
}));
const Order=mongoose.model('Order',new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},item:String,quantity:Number,status:{type:String,default:'Pending'},
 createdAt:{type:Date,default:Date.now}
}));
const Post=mongoose.model('Post',new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},author:String,title:String,body:String,
 createdAt:{type:Date,default:Date.now}
}));

function auth(req,res,next){
 const token=(req.headers.authorization||'').replace('Bearer ','');
 try{req.user=jwt.verify(token,process.env.JWT_SECRET||'dev_secret_change_me');next();}
 catch{return res.status(401).json({message:'Please log in to continue'});}
}
function admin(req,res,next){if(req.user.role!=='admin')return res.status(403).json({message:'Admin access required'});next();}
const asyncRoute=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);

app.post('/api/auth/register',asyncRoute(async(req,res)=>{
 const {name,email,password}=req.body;
 if(!name||!email||!password||password.length<6)return res.status(400).json({message:'Name, email and password (6+ chars) are required'});
 if(await User.findOne({email}))return res.status(409).json({message:'Email already registered'});
 const user=await User.create({name,email,password:await bcrypt.hash(password,10)});
 res.status(201).json({token:jwt.sign({id:user._id,role:user.role},process.env.JWT_SECRET||'dev_secret_change_me',{expiresIn:'7d'}),user:{id:user._id,name,email,role:user.role}});
}));
app.post('/api/auth/login',asyncRoute(async(req,res)=>{
 const user=await User.findOne({email:req.body.email});
 if(!user||!await bcrypt.compare(req.body.password,user.password))return res.status(401).json({message:'Invalid email or password'});
 res.json({token:jwt.sign({id:user._id,role:user.role},process.env.JWT_SECRET||'dev_secret_change_me',{expiresIn:'7d'}),user:{id:user._id,name:user.name,email:user.email,role:user.role}});
}));
app.get('/api/auth/me',auth,asyncRoute(async(req,res)=>{const u=await User.findById(req.user.id).select('-password');res.json(u);}));

const crud=(path,Model,fields)=> {
 app.get(`/api/${path}`,auth,asyncRoute(async(req,res)=>res.json(await Model.find({user:req.user.id}).sort({createdAt:-1}))));
 app.post(`/api/${path}`,auth,asyncRoute(async(req,res)=>res.status(201).json(await Model.create({...Object.fromEntries(fields.map(f=>[f,req.body[f]])),user:req.user.id}))));
 app.put(`/api/${path}/:id`,auth,asyncRoute(async(req,res)=>{
   const item=await Model.findOneAndUpdate({_id:req.params.id,user:req.user.id},Object.fromEntries(fields.map(f=>[f,req.body[f]])),{new:true});
   if(!item)return res.status(404).json({message:'Record not found'});res.json(item);
 }));
 app.delete(`/api/${path}/:id`,auth,asyncRoute(async(req,res)=>{
   const item=await Model.findOneAndDelete({_id:req.params.id,user:req.user.id});
   if(!item)return res.status(404).json({message:'Record not found'});res.json({message:'Deleted'});
 }));
};
crud('farms',Farm,['name','location','area','soilType']);
crud('crops',Crop,['farm','name','variety','sowingDate','stage','health','notes']);
crud('soil',SoilReport,['farm','ph','nitrogen','phosphorus','potassium','notes']);
crud('alerts',Alert,['title','message','severity']);
crud('orders',Order,['item','quantity','status']);

app.get('/api/weather',asyncRoute(async(req,res)=>{
 const lat=Number(req.query.lat||28.6139),lon=Number(req.query.lon||77.2090);
 const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=5`;
 const response=await fetch(url);if(!response.ok)throw new Error('Weather provider unavailable');
 res.json(await response.json());
}));
app.get('/api/posts',auth,asyncRoute(async(req,res)=>res.json(await Post.find().sort({createdAt:-1}).limit(100))));
app.post('/api/posts',auth,asyncRoute(async(req,res)=>{
 const p=await Post.create({user:req.user.id,author:req.body.author||'Farmer',title:req.body.title,body:req.body.body});
 res.status(201).json(p);
}));
app.get('/api/admin/stats',auth,admin,asyncRoute(async(req,res)=>res.json({
 users:await User.countDocuments(),farms:await Farm.countDocuments(),crops:await Crop.countDocuments(),orders:await Order.countDocuments()
})));
app.get('/api/health',(req,res)=>res.json({status:'ok'}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({message:err.message||'Server error'});});
const port=process.env.PORT||5000;
mongoose.connect(process.env.MONGO_URI||'mongodb://127.0.0.1:27017/agritech')
.then(()=>app.listen(port,()=>console.log(`AgriTech API running on ${port}`)))
.catch(err=>{console.error('MongoDB connection failed:',err.message);process.exit(1);});
