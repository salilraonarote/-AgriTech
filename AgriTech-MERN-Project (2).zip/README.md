# AgriTech — Smart Farming Management System (MERN)

A starter full-stack project based on the provided specification/screenshots:
- React + Bootstrap frontend
- Node.js + Express REST API
- MongoDB (Mongoose)
- JWT authentication with farmer/admin roles
- Farm profile and crop CRUD
- Weather forecast (Open-Meteo; no API key required)
- Soil health reports, pest alerts, resource orders
- Expert consultation/community forum
- Admin dashboard and multilingual UI (English/Hindi UI toggle)

## Requirements
Install Node.js 18+ and npm. Use MongoDB locally or MongoDB Atlas.

## Setup
1. Extract this ZIP.
2. Open a terminal in the extracted `AgriTech-MERN` folder.
3. Install backend dependencies:
   ```bash
   cd backend
   npm install
   copy .env.example .env
   ```
   Edit `.env` and set `MONGO_URI` and a long `JWT_SECRET`.
4. Start backend:
   ```bash
   npm run dev
   ```
5. Open a second terminal:
   ```bash
   cd frontend
   npm install
   npm start
   ```
6. Visit http://localhost:3000

The backend runs at http://localhost:5000. React proxy is configured for it.

## Create an admin
Register normally, then in MongoDB update that user's `role` to `admin`.
For example, in MongoDB Compass edit the user document and set `"role": "admin"`.

## Notes
- Weather endpoint uses Open-Meteo forecast API.
- Weather location defaults to New Delhi; change it in the Weather page.
- This is a learning/demo project. Before production, add rate limiting, email verification,
  robust input validation, tests, secure deployment configuration, and review all security settings.
